﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace WindowsFormsApp5
{
    public partial class RubricLevel : Form
    {
        public RubricLevel()
        {
            string connectionString = "Data Source=THEONE;Initial Catalog=ProjectB;Integrated Security=True";
            InitializeComponent();
            DisplayRubricLevelData();
            List<string> dataSource = new List<string>();
            List<string> dataSource1 = new List<string>();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {

                connection.Open();
                SqlCommand command = new SqlCommand("SELECT id from Rubric", connection);
                SqlDataReader reader = command.ExecuteReader();

                // Clear existing items in the combobox
                

                while (reader.Read())
                {
                    // Add each ID to the combobox
                    dataSource.Add(reader["Id"].ToString());
                }
            }
            comboBox1.DataSource = dataSource;
            

        }




            private void RubricLevel_Load(object sender, EventArgs e)
        {
           

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            // Get the details entered by the user
            string details = textBox1.Text.Trim(); // Trim any leading or trailing whitespace

            // Check if the details are empty
            if (string.IsNullOrWhiteSpace(details))
            {
                // If details are empty, display an error message
                MessageBox.Show("Details cannot be empty. Please enter valid details.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                textBox1.Focus(); // Set focus back to textBox1
                return;
            }

            // Validation passed, you can use the 'details' variable as needed
        }


        private void DisplayRubricLevelData()
        {
            try
            {
                string connectionString = "Data Source=THEONE;Initial Catalog=ProjectB;Integrated Security=True";
                string selectQuery = "SELECT ID, RubricId, Details, MeasurementLevel FROM RubricLevel";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    SqlDataAdapter adapter = new SqlDataAdapter(selectQuery, connection);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);

                    // Clear existing columns
                    dataGridView1.Columns.Clear();

                    dataGridView1.DataSource = dataTable;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                // Get input data from the user
                int rubricId;
                if (!int.TryParse(comboBox1.Text, out rubricId))
                {
                    MessageBox.Show("Please enter a valid integer for Rubric ID.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                string details = textBox1.Text;
                int measurementLevel;
                if (!int.TryParse(textBox2.Text, out measurementLevel))
                {
                    MessageBox.Show("Please enter a valid integer for Measurement Level.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // Check if the same data already exists
                string connectionString = "Data Source=THEONE;Initial Catalog=ProjectB;Integrated Security=True";
                string selectQuery = "SELECT COUNT(*) FROM RubricLevel WHERE RubricId = @RubricId AND Details = @Details AND MeasurementLevel = @MeasurementLevel";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand(selectQuery, connection);
                    command.Parameters.AddWithValue("@RubricId", rubricId);
                    command.Parameters.AddWithValue("@Details", details);
                    command.Parameters.AddWithValue("@MeasurementLevel", measurementLevel);

                    connection.Open();
                    int existingCount = (int)command.ExecuteScalar();

                    if (existingCount > 0)
                    {
                        MessageBox.Show("The same Rubric Level already exists.", "Duplicate Entry", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return; // Exit the method without adding duplicate data
                    }
                }

                // If the Rubric Level does not already exist, proceed with insertion
                string insertQuery = "INSERT INTO RubricLevel (RubricId, Details, MeasurementLevel) VALUES (@RubricId, @Details, @MeasurementLevel)";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand(insertQuery, connection);
                    command.Parameters.AddWithValue("@RubricId", rubricId);
                    command.Parameters.AddWithValue("@Details", details);
                    command.Parameters.AddWithValue("@MeasurementLevel", measurementLevel);

                    connection.Open();
                    int rowsAffected = command.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Rubric Level added successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                        // Refresh the DataGridView to reflect the updated data
                        DisplayRubricLevelData();
                    }
                    else
                    {
                        MessageBox.Show("Failed to add Rubric Level!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private bool RubricIdExists(int rubricId)
        {
            bool exists = false;
            try
            {
                string connectionString = "Data Source=THEONE;Initial Catalog=ProjectB;Integrated Security=True";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    // Check if the Rubric Id exists in the RubricLevel table
                    string selectQuery = "SELECT COUNT(*) FROM RubricLevel WHERE RubricId = @RubricId";
                    using (SqlCommand command = new SqlCommand(selectQuery, connection))
                    {
                        command.Parameters.AddWithValue("@RubricId", rubricId);
                        int count = (int)command.ExecuteScalar();
                        exists = (count > 0);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred while checking if Rubric ID exists: " + ex.Message);
            }
            return exists;
        }



        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void fillByToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.rubricTableAdapter1.FillBy(this.projectBDataSet7.Rubric);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                // Retrieve the selected ID from the DataGridView
                int selectedId = 0; // Assuming the ID is an integer
                if (dataGridView1.SelectedRows.Count > 0)
                {
                    DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];
                    selectedId = Convert.ToInt32(selectedRow.Cells["ID"].Value);
                }
                else
                {
                    MessageBox.Show("Please select a Rubric Level to update.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // Get input data from the user
                int rubricId;
                if (!int.TryParse(comboBox1.Text, out rubricId))
                {
                    MessageBox.Show("Please enter a valid integer for Rubric ID.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                string details = textBox1.Text;
                int measurementLevel;
                if (!int.TryParse(textBox2.Text, out measurementLevel))
                {
                    MessageBox.Show("Please enter a valid integer for Measurement Level.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // Check if the updated data already exists (excluding the current ID)
                string connectionString = "Data Source=THEONE;Initial Catalog=ProjectB;Integrated Security=True";
                string selectQuery = "SELECT COUNT(*) FROM RubricLevel WHERE RubricId = @RubricId AND Details = @Details AND MeasurementLevel = @MeasurementLevel AND ID != @ID";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand selectCommand = new SqlCommand(selectQuery, connection);
                    selectCommand.Parameters.AddWithValue("@RubricId", rubricId);
                    selectCommand.Parameters.AddWithValue("@Details", details);
                    selectCommand.Parameters.AddWithValue("@MeasurementLevel", measurementLevel);
                    selectCommand.Parameters.AddWithValue("@ID", selectedId);

                    connection.Open();
                    int duplicateCount = (int)selectCommand.ExecuteScalar();

                    if (duplicateCount > 0)
                    {
                        MessageBox.Show("The updated Rubric Level already exists.", "Duplicate Entry", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return; // Exit the method without updating if duplicate data found
                    }
                }

                // If no duplicate data found, proceed with updating
                string updateQuery = "UPDATE RubricLevel SET RubricId = @RubricId, Details = @Details, MeasurementLevel = @MeasurementLevel WHERE ID = @ID";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand(updateQuery, connection);
                    command.Parameters.AddWithValue("@RubricId", rubricId);
                    command.Parameters.AddWithValue("@Details", details);
                    command.Parameters.AddWithValue("@MeasurementLevel", measurementLevel);
                    command.Parameters.AddWithValue("@ID", selectedId);

                    connection.Open();
                    int rowsAffected = command.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Rubric Level updated successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                        // Refresh the DataGridView to reflect the updated data
                        DisplayRubricLevelData();
                    }
                    else
                    {
                        MessageBox.Show("Failed to update Rubric Level!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            // Check if a valid row is clicked (not the header row and within the range of rows)
            if (e.RowIndex >= 0 && e.RowIndex < dataGridView1.Rows.Count - 1)
            {
                // Get the selected row
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];

                // Extract Rubric ID, Details, and Measurement Level from the selected row
                int rubricId = Convert.ToInt32(row.Cells["RubricIDColumn"].Value);
                string details = row.Cells["DetailsColumn"].Value.ToString();
                int measurementLevel = Convert.ToInt32(row.Cells["MeasurementLevelColumn"].Value);

                // Update the corresponding text boxes with the extracted values
                comboBox1.Text = rubricId.ToString(); // Assuming comboBox1 is used for Rubric ID
                textBox1.Text = details; // Assuming textBox1 is used for Details
                textBox2.Text = measurementLevel.ToString(); // Assuming textBox2 is used for Measurement Level
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                // Retrieve the selected ID from the DataGridView
                int selectedId = 0; // Assuming the ID is an integer
                if (dataGridView1.SelectedRows.Count > 0)
                {
                    DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];
                    selectedId = Convert.ToInt32(selectedRow.Cells["ID"].Value);
                }
                else
                {
                    MessageBox.Show("Please select a Rubric Level to delete.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // Prompt the user to confirm deletion
                DialogResult result = MessageBox.Show("Are you sure you want to delete this Rubric Level?", "Confirm Deletion", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    // Perform deletion
                    string connectionString = "Data Source=THEONE;Initial Catalog=ProjectB;Integrated Security=True";
                    string deleteQuery = "DELETE FROM RubricLevel WHERE ID = @ID";

                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        SqlCommand command = new SqlCommand(deleteQuery, connection);
                        command.Parameters.AddWithValue("@ID", selectedId);

                        connection.Open();
                        int rowsAffected = command.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Rubric Level deleted successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                            // Refresh the DataGridView to reflect the updated data
                            DisplayRubricLevelData();
                        }
                        else
                        {
                            MessageBox.Show("Failed to delete Rubric Level!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            // Create an instance of the AddComponent form
            AddComponent addComponentForm = new AddComponent();

            // Show the AddComponent form
            addComponentForm.Show();
        }

        private void linkLabel4_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Lookup lookupForm = new Lookup();
            lookupForm.Show();
        }

        private void linkLabel3_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            StudentResult result = new StudentResult();
            result.Show();
        }
    }
}
